<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:65:"D:\phpStudy\WWW\tp5/application/mobile\view\account\register.html";i:1516601177;s:62:"D:\phpStudy\WWW\tp5\application\mobile\view\common\header.html";i:1516604455;s:62:"D:\phpStudy\WWW\tp5\application\mobile\view\common\footer.html";i:1516604434;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="initial-scale=1, maximum-scale=1, user-scalable=no"  />
<title>注册</title>
<link rel="stylesheet" type="text/css" href="/tp5/public/static/mobile/css/all.css">
<link rel="stylesheet" type="text/css" href="/tp5/public/static/mobile/css/style.css?v1.3">
<link rel="stylesheet" type="text/css" href="/tp5/public/static/mobile/css/alert.css">
</head>
<body class="white-bg">

<article class="am-container">
    <div class="register">
        <ul class="mid">
            <li>
                <label>+86</label>
                <input type="number" id="mobile" placeholder="手机号">
            </li>
            <li>
                <input type="text" id="identity" placeholder="请输入身份证号">
            </li>
            <li>
                <input type="text" id="realname" placeholder="请输入真实姓名">
            </li>
            <li>
                <input type="password" id="pwd1" placeholder="请输入密码">
            </li>
            <li>
                <input type="password" id="pwd2" placeholder="请重复输入密码">
            </li>
        </ul>

        <div class="submit active">
            <button class="btn" id="btn">立即注册</button>
        </div>
    </div>
</article>
<script type="text/javascript" src="/tp5/public/static/mobile/js/jquery-2.1.4.js"></script>
<script type="text/javascript" src="/tp5/public/static/mobile/js/alert.js"></script>
</body>
</html>
<script>
    $('#btn').click(function(){
        var mobile = $('#mobile').val();
        if(mobile==''){
            Jacky._alert('手机号不能为空');return;
        }
        var checktel=/^0?1[3|4|5|8][0-9]\d{8}$/;
        var res=checktel.test(mobile);
        if(!res){
            Jacky._alert('请输入11位的手机号码');return;
        }
        var identity = $('#identity').val();
        if(identity==''){
            Jacky._alert('身份证号不能为空');return;
        }
        var reg = /(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/;  
        if(!reg.test(identity)){
            Jacky._alert('请输入正确的身份证号码');return;
        }
        var realname = $('#realname').val();
        if(realname==''){
            Jacky._alert('请输入真实姓名');return;
        }
        var pwd1 = $('#pwd1').val();
        if(pwd1==''){
            Jacky._alert('请输入密码');return;
        }
        var pwd2 = $('#pwd2').val();
        if(pwd2==''){
            Jacky._alert('请再次输入密码');return;
        }
        if(pwd1!=pwd2){
            Jacky._alert('两次输入的密码不一致');return;
        }

        var submitData = {
            mobile : mobile,
            identity : identity,
            realname : realname,
            password : pwd1
        }

        $.post('<?php echo url('/mobile/account/register'); ?>',submitData,function(data){
            if(data==-1){
                Jacky._alert('注册失败');
            }else{
                Jacky._alert('注册成功');
                setTimeout(function(){
                    location.href='<?php echo url('/mobile/account/login'); ?>';
                },2000);
            }
        },'json');
    })
</script>
