<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:71:"D:\phpStudy\WWW\tpmianshi-finish/application/home\view\index\index.html";i:1516612337;}*/ ?>
<!DOCTYPE html PUBddC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="initial-scale=1, maximum-scale=1, user-scalable=no"  />
<meta name="apple-mobile-web-app-status-bar-style" content="black" />
<meta name="format-detection" content="telephone=no" />
<meta name="format-detection" content="email=no" />
<title>聆科面试题</title>
<style>
	body{font-family:"微软雅黑";}
	dt{ font-size:18px; padding:6px 0; margin-bottom:6px; background-color:#999; text-indent:15px; color:#fff;}
	dd{ padding:6px 0; margin-bottom:4px;margin: 0;}
	dd a{ font-size:16px; line-height:22px; color:#000; display:inline-block; text-decoration:none;}
	dd a.red{ color:#930;}
	dd a:hover{ color:#600; text-decoration:underline;}
	.button{
		position: fixed;
		width: 100%;
		padding: 10px;
		bottom: 0;
		left: 0;
		right: 0;
	    box-sizing: border-box;
	    background: #fff;
	}
	.button a{
		background: red;
		border-radius: 4px;
		height: 40px;
		line-height: 40px;
		text-align: center;
		color: #fff;
		font-size: 16px;
		display: block;
		text-decoration : none;
	}
	body{
		padding-bottom: 50px;
	}
</style>
</head>

<body>

<div>
	<dl>
    	<dt>题目简介</dt>
    	<dd>1、简单用户注册登录功能。</dd>
    	<dd>2、本机试程序是基于ThinkPHP V5.0.14，请把文件夹名重命名为你自己的名字。</dd>
    	<dd>3、数据库SQL文件喜爱程序的根目录下，请根据数据库设计的表和字段进行实操。</dd>
    	<dd>4、如果不会用ThinkPHP V5.0.14框架的，可以向面试人员提出使用其他框架或者实现方式。</dd>
    </dl>
    <dl>
    	<dt>机试要求</dt>
    	<dd>1、无明显或严重的BUG。</dd>
    	<dd>2、功能要符合合理的业务流程。</dd>
    	<dd>3、所有的表单提交都必须使用AJAX技术，弹出特效必须使用程序提供的特效(代码里有案例)。</dd>
    	<dd>4、机试时间为2个小时，超出时间即停止测试。</dd>
    </dl>
    <dl>
    	<dt>评分标准</dt>
    	<dd>1、本机试满分为100分。</dd>
    	<dd>2、登录页面：页面功能全部完成+15分，未使用合适的过滤去验证表单-5分，不能登录0分。</dd>
    	<dd>3、注册页面：页面功能全部完成+30分，未使用合适的过滤去验证表单-10分，不能注册0分。</dd>
    	<dd>4、会员中心页面：页面功能全部完成+15分，变量未输出好-5分，退出功能不行或者未做-5分，功能未做好0分。</dd>
    	<dd>5、我的资料：页面功能全部完成+20分，未使用合适的过滤去验证表单-10分，不能修改0分。</dd>
    	<dd>6、业务代码：总分20分，会根据你的代码设计和风格去评定。</dd>
    </dl>
    <div class="button"><a href="<?php echo url('/index.php/mobile/account/login'); ?>">点击进入面试题</a></div>
</div>

</body>
</html>
