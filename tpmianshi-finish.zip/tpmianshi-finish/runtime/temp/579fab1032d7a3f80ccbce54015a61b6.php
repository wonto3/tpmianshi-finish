<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:62:"D:\phpStudy\WWW\tp5/application/mobile\view\account\login.html";i:1516601682;s:62:"D:\phpStudy\WWW\tp5\application\mobile\view\common\header.html";i:1516604455;s:62:"D:\phpStudy\WWW\tp5\application\mobile\view\common\footer.html";i:1516604434;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="initial-scale=1, maximum-scale=1, user-scalable=no"  />
<title>登录</title>
<link rel="stylesheet" type="text/css" href="/tp5/public/static/mobile/css/all.css">
<link rel="stylesheet" type="text/css" href="/tp5/public/static/mobile/css/style.css?v1.3">
<link rel="stylesheet" type="text/css" href="/tp5/public/static/mobile/css/alert.css">
</head>
<body class="white-bg">
<article class="am-container">
    <div class="login">
        <div class="logo">
            <img src="/tp5/public/static/mobile/images/DM.png">
        </div>
        <ul class="mid">
            <li>
                <input type="number" id="mobile" placeholder="请输入手机号码">
            </li>
            <li>
                <input type="password" id="password" placeholder="请输入密码">
            </li>
        </ul>

        <div class="submit active">
            <button class="btn" id="btn">登录</button>
        </div>
        
        <div class="bottom">
            <a href="<?php echo url('/mobile/account/register'); ?>">新用户注册</a>
            <a href="<?php echo url('/mobile/member'); ?>">会员中心</a>
        </div>
    </div>
</article>
<script type="text/javascript" src="/tp5/public/static/mobile/js/jquery-2.1.4.js"></script>
<script type="text/javascript" src="/tp5/public/static/mobile/js/alert.js"></script>
</body>
</html>
<script>
    //弹出特效：Jacky._alert('xxxx');
    $('#btn').click(function(){
        var mobile = $('#mobile').val();
        if(mobile==''){
            Jacky._alert('手机号不能为空');return;
        }
        var checktel=/^0?1[3|4|5|8][0-9]\d{8}$/;
        var res=checktel.test(mobile);
        if(!res){
            Jacky._alert('请输入11位的手机号码');return;
        }
        var password = $('#password').val();
        if(password==''){
            Jacky._alert('密码不能为空');return;
        }

        var submitData = {
            mobile : mobile,
            password : password
        }

        $.post('<?php echo url('/mobile/account/login'); ?>',submitData,function(data){
            if(data==-1 || data==-2){
                Jacky._alert('帐号或密码错误');
            }else{
                Jacky._alert('登录成功');
                setTimeout(function(){
                    location.href='<?php echo url('/mobile/member'); ?>';
                },2000);
            }
        },'json');
    })
</script>
