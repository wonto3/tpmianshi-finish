<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:64:"D:\phpStudy\WWW\tp5/application/mobile\view\member\userinfo.html";i:1516608016;s:62:"D:\phpStudy\WWW\tp5\application\mobile\view\common\header.html";i:1516604455;s:62:"D:\phpStudy\WWW\tp5\application\mobile\view\common\footer.html";i:1516604434;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="initial-scale=1, maximum-scale=1, user-scalable=no"  />
<title>我的资料</title>
<link rel="stylesheet" type="text/css" href="/tp5/public/static/mobile/css/all.css">
<link rel="stylesheet" type="text/css" href="/tp5/public/static/mobile/css/style.css?v1.3">
<link rel="stylesheet" type="text/css" href="/tp5/public/static/mobile/css/alert.css">
</head>
<body class="white-bg">

<article class="am-container">
    <div class="myData">
        <div class="head">
          <img src="/tp5/public/static/mobile/images/user-head.png"></img>
        </div>

        <div class="form">
          <div class="item">
            <label class="name">姓名：</label>
            <div class="iBox">
              <input placeholder="请填写姓名" id="realname" value="<?php echo $user['realname']; ?>" />
            </div>
          </div>
          <div class="item">
            <label class="name">手机：</label>
            <div class="iBox">
              <input placeholder="请填写手机号" id="mobile" value="<?php echo $user['mobile']; ?>" />
            </div>
          </div>
          <div class="item">
            <label class="name">身份证：</label>
            <div class="iBox">
              <input placeholder="请填写身份证" id="identity" value="<?php echo $user['identity']; ?>" />
            </div>
          </div>
          <div class="item">
            <label class="name">性别：</label>
            <div class="cBox">
                <label class=" active">
                    <input type="radio" name="radio1" id="x11" value="1" <?php if($user['sex'] == 1): ?>checked="checked"<?php endif; ?>>
                    <span>男</span>
                </label>
                <label class="">
                    <input type="radio" name="radio1" id="x12" value="0" <?php if($user['sex'] == 0): ?>checked="checked"<?php endif; ?>>
                    <span>女</span>
                </label>
            </div>
          </div>
        </div>

        <text class="tip">以上信息将用于您的会员身份识别<br/>请如实填写</text>

        <div class="submit active">
            <button class="btn" id="btn">保存信息</button>
        </div>
    </div>

</article>
<script type="text/javascript" src="/tp5/public/static/mobile/js/jquery-2.1.4.js"></script>
<script type="text/javascript" src="/tp5/public/static/mobile/js/alert.js"></script>
</body>
</html>
<script>
  $('#btn').click(function(){
    var realname = $('#realname').val();
    if(realname==''){
      Jacky._alert('请填写姓名');
    }
    var mobile = $('#mobile').val();
    if(mobile==''){
        Jacky._alert('手机号不能为空');return;
    }
    var checktel=/^0?1[3|4|5|8][0-9]\d{8}$/;
    var res=checktel.test(mobile);
    if(!res){
        Jacky._alert('请输入11位的手机号码');return;
    }
    var identity = $('#identity').val();
    if(identity==''){
        Jacky._alert('身份证号不能为空');return;
    }
    var reg = /(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/;  
    if(!reg.test(identity)){
        Jacky._alert('请输入正确的身份证号码');return;
    }
    var sex = $("input[name='radio1']:checked").val();

    var submitData = {
      realname : realname,
      mobile : mobile,
      identity : identity,
      sex : sex
    }

    $.post('<?php echo url('/mobile/member/userinfo'); ?>',submitData,function(data){
        if(data==1){
          Jacky._alert('修改成功');
          setTimeout(function(){
              location.href='<?php echo url('/mobile/member'); ?>';
          },2000);
        }
    },'json');
  })
</script>
