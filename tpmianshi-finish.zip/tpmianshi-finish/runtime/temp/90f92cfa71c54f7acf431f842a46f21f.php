<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:74:"D:\phpStudy\WWW\tpmianshi-finish/application/mobile\view\member\index.html";i:1516606426;s:75:"D:\phpStudy\WWW\tpmianshi-finish\application\mobile\view\common\header.html";i:1516604455;s:75:"D:\phpStudy\WWW\tpmianshi-finish\application\mobile\view\common\footer.html";i:1516604434;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="initial-scale=1, maximum-scale=1, user-scalable=no"  />
<title>会员中心</title>
<link rel="stylesheet" type="text/css" href="/tpmianshi-finish/public/static/mobile/css/all.css">
<link rel="stylesheet" type="text/css" href="/tpmianshi-finish/public/static/mobile/css/style.css?v1.3">
<link rel="stylesheet" type="text/css" href="/tpmianshi-finish/public/static/mobile/css/alert.css">
</head>
<body class="white-bg">

<article class="am-container vipCenter">
    <div class="head">
        <div class="cell">
            <div class="top">
                <img src="/tpmianshi-finish/public/static/mobile/images/user-head.png">
                <dl>
                    <dt>
                        <div class="name"><?php echo $user['realname']; ?></div>
                    </dt>
                    <dd><?php echo $user['mobile']; ?></dd>
                </dl>
            </div>
        </div>
    </div>

    <ul class="list">
        <li class="item" onclick="location.href='<?php echo url('/mobile/member/userinfo'); ?>'">
            <img class="icon" src="/tpmianshi-finish/public/static/mobile/images/vipList-icon2.png">
            <label>我的资料</label>
        </li>
    </ul>

    <a class="logout" href="javascript:;">退出登录</a>

</article>
<script type="text/javascript" src="/tpmianshi-finish/public/static/mobile/js/jquery-2.1.4.js"></script>
<script type="text/javascript" src="/tpmianshi-finish/public/static/mobile/js/alert.js"></script>
</body>
</html>
<script>
    $('.logout').click(function(){
        Jacky._alert('退出成功');
        $.post('<?php echo url('/mobile/member/logout'); ?>',{'doit':'logout'},function(data){
            setTimeout(function(){
                location.href='<?php echo url('/mobile/account/login'); ?>';
            },2000);
        },'json');
    })
</script>
