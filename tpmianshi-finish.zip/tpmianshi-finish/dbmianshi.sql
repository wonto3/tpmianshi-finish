-- phpMyAdmin SQL Dump
-- version phpStudy 2014
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2018 �?01 �?22 �?08:58
-- 服务器版本: 5.5.53
-- PHP 版本: 5.6.27

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `dbmianshi`
--

-- --------------------------------------------------------

--
-- 表的结构 `tp_account`
--

CREATE TABLE IF NOT EXISTS `tp_account` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mobile` varchar(25) NOT NULL COMMENT '手机号码',
  `password` varchar(50) NOT NULL COMMENT '密码',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='帐号表' AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `tp_account`
--

INSERT INTO `tp_account` (`id`, `mobile`, `password`) VALUES
(1, '13798164004', 'e10adc3949ba59abbe56e057f20f883e');

-- --------------------------------------------------------

--
-- 表的结构 `tp_user`
--

CREATE TABLE IF NOT EXISTS `tp_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `aid` int(11) NOT NULL DEFAULT '0' COMMENT '帐号ID',
  `mobile` varchar(25) NOT NULL COMMENT '手机号码',
  `realname` varchar(50) NOT NULL COMMENT '真实姓名',
  `identity` varchar(25) NOT NULL COMMENT '身份证号码',
  `sex` tinyint(1) NOT NULL DEFAULT '0' COMMENT '性别，0为男，1为女',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='会员表' AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `tp_user`
--

INSERT INTO `tp_user` (`id`, `aid`, `mobile`, `realname`, `identity`, `sex`) VALUES
(1, 1, '13798164004', 'hao', '440181198905123331', 0);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
