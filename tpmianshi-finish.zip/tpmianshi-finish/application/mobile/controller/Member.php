<?php
namespace app\mobile\controller;
use think\Db;
use think\Request;
use think\Cookie;

class Member extends \think\Controller
{
	public function index()
	{
		$uid = Cookie::get('uid');
		if(!$uid){
			$url = url('/mobile/account/login');
			header('Location:'.$url);exit();
		}
		$user = Db::name('user')->field('realname,mobile')->where(array('id'=>$uid))->find();
		$this->assign('user',$user);
		return view('index');
	}

	public function userinfo()
	{
		$uid = Cookie::get('uid');
		if(!$uid){
			$url = url('/mobile/account/login');
			header('Location:'.$url);exit();
		}
		$user = Db::name('user')->where(array('id'=>$uid))->find();
		$this->assign('user',$user);
		if(Request::instance()->isAjax()){
			$postdata = Request::instance()->post();
			Db::name('user')->where(array('id'=>$uid))->update($postdata);
			echo 1;exit();
		}
		return view('userinfo');
	}

	public function logout()
	{
		if(Request::instance()->isAjax()){
			Cookie::delete('uid');
			echo 1;exit();
		}
	}
}
?>