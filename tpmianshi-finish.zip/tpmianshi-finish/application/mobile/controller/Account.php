<?php
namespace app\mobile\controller;
use think\Db;
use think\Request;
use think\Cookie;

class Account
{
	//登录
	public function login()
	{
		$uid = Cookie::get('uid');
		if($uid){
			$url = url('/mobile/member');
			header('Location:'.$url);exit();
		}
		if(Request::instance()->isAjax()){
			$postdata = Request::instance()->post();
			$mobile = $postdata['mobile'];
			$password = $postdata['password'];
			$account = Db::name('account')->where(array('mobile'=>$mobile))->find();
			if(!$account){
				echo -1;exit();
			}else{
				if($account['password']!=md5($password)){
					echo -2;exit();
				}else{
					$aid = $account['id'];
					$uid = Db::name('user')->where(array('aid'=>$aid))->value('id');
					Cookie::set('uid',$uid,60*60);
					echo 1;exit();
				}
			}
		}
		return view('login');
	}

	//注册
	public function register()
	{
		if(Request::instance()->isAjax()){
			$postdata = Request::instance()->post();
			$mobile = $postdata['mobile'];
			$identity = $postdata['identity'];
			$realname = $postdata['realname'];
			$password = $postdata['password'];
			$account = Db::name('account')->where(array('mobile'=>$mobile))->find();
			if($account){
				echo -1;exit();
			}else{
				$accountData['mobile'] = $mobile;
				$accountData['password'] = md5($password);
				Db::name('account')->insert($accountData);
				$aid = Db::name('account')->getLastInsID();
				$userData['aid'] = $aid;
				$userData['mobile'] = $mobile;
				$userData['realname'] = $realname;
				$userData['identity'] = $identity;
				Db::name('user')->insert($userData);
				echo 1;exit();
			}
		}
		return view('register');
	}
}

?>