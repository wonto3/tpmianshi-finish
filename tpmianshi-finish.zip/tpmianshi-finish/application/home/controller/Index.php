<?php
namespace app\home\controller;
use think\Db;

class Index
{
    public function index()
    {
    	return view('index');
    }
}
