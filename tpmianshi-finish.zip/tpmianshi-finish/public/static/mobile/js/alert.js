Jacky = {
    hidePhoneAddrBar: function() {
        setTimeout(function() {
            window.scrollTo(0, 0);
        },
        100)
    },
    toTop: function() {
        var b = null,
        c = $(window),
        a = $("#srcollTop");
        c.on("scroll",
        function() {
        });
        a.on("click",
        function() {
            window.scroll(0, 0)
        })
    },
	_alert : function(txt,time,callback){
		if(!time){
			time = 1000;
		}
		if($("#ts_alert_bg").length){
			$("#ts_alert_bg").show();
		}
		else{
			var _d = document;
			var _alert_bg = _d.createElement("div");
			_alert_bg.setAttribute("id","ts_alert_bg");
			_d.body.appendChild(_alert_bg);
			
			var _alert_content = _d.createElement("div");
			_alert_content.setAttribute("id","ts_alert_content");
			_alert_bg.appendChild(_alert_content);
		}
		var _this = $("#ts_alert_content");
		_this.html(txt).fadeIn(function(){
			setTimeout(function(){
				_this.fadeOut(function(){
					$("#ts_alert_bg").hide();
					callback && callback();
				})
			},time)
		});
	},
    tabs: function(tabTit, on, tabCon) {
        $(tabCon).each(function() {
            $(this).children().eq(0).show();
        });
        $(tabTit).each(function() {
            $(this).children().eq(0).addClass(on);
        });
        $(tabTit).children().bind("touchstart click",
        function() {
            $(this).addClass(on).siblings().removeClass(on);
            var index = $(tabTit).children().index(this);
            $(tabCon).children().eq(index).show().siblings().hide();
        });
    },
    setCookie: function(name, value) {
        var Days = 30;
        var exp = new Date();
        exp.setTime(exp.getTime() + Days * 24 * 60 * 60 * 1000);
        document.cookie = name + "=" + escape(value) + ";expires=" + exp.toGMTString();
    },
    getCookie: function(name) {
        var arr = document.cookie.match(new RegExp("(^| )" + name + "=([^;]*)(;|$)"));
        if (arr != null) return unescape(arr[2]);
        return null;
    }
}